
extends Base_Enemy

func _ready():
	super._ready()
	speed = 30.0 # Slower
	health.max_health = 120.0 # Tankier
	health.current_health = 120.0
	aggroFloat = 1.4
