extends Base_Enemy

func _ready():
	super._ready()
	speed = 20.0 # Slower
	health.max_health = 65.0 # Tankier
	health.current_health = 65.0
	aggroFloat = 2
