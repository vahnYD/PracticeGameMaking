extends Base_Enemy

func _ready():
	super._ready()
	speed = 15.0 # Slower
	health.max_health = 200.0 # Tankier
	health.current_health = 200.0
	aggroFloat = 0.8
